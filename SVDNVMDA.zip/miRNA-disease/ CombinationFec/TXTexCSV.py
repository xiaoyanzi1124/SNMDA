import numpy as np
import pandas as pd

data_txt = np.loadtxt('miRNAembeddings_node2vec_64.vector')
data_txtDF = pd.DataFrame(data_txt)
data_txtDF.to_csv('miRNAembeddings_node2vec_64.csv', index=False)