#coding=utf-8
import warnings

import networkx as nx
#from node2vec_.node2vec import Node2Vec
import pandas as pd
from node2vec import Node2Vec
import csv

def ReadMyCsv(SaveList, fileName):
    csv_reader = csv.reader(open(fileName, encoding='utf-8'))
    for row in csv_reader:
        SaveList.append(row)
    return

def StorFile(data, fileName):
    with open(fileName, "w", newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerows(data)
    return

def ReadMyCsv(SaveList, fileName):
    csv_reader = csv.reader(open(fileName, encoding='utf-8'))
    for row in csv_reader:
        SaveList.append(row)
    return

def StorFile(data, fileName):
    with open(fileName, "w", newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerows(data)
    return

import numpy as np

def txt2array(txt_path, delimiter):
    #---
    # 功能：读取只包含数字的txt文件，并转化为array形式
    # txt_path：txt的路径；delimiter：数据之间的分隔符
    #---
    data_list = []
    with open(txt_path) as f:
        data = f.readlines()
    for line in data:
        line = line.strip("\n")  # 去除末尾的换行符
        data_split = line.split(delimiter)
        temp = list(map(float, data_split))
        data_list.append(temp)

    data_array = np.array(data_list)
    return data_array
    #return data_list

warnings.filterwarnings('ignore')
array = txt2array("E:\pythonproject\miRNA-disease\disease-result.txt", delimiter=' ')
print(array)
G = nx.from_numpy_matrix(array)
node2vec = Node2Vec(G,dimensions=64,walk_length=10,num_walks=80,p=0.25, q=4,workers=4)
model1 =node2vec.fit(window=5,min_count=1, batch_words=4)
model1.wv.save_word2vec_format('embeddings_node2vec_64.vector')
