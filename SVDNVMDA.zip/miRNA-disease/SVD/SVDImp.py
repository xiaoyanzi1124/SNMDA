import numpy as np
import pandas as pd

DFdata = pd.read_csv('R-D.csv', header=None)
ArrDate = np.array(DFdata)
repMart = np.where(ArrDate==0, 0.0000000001, 1)

print(ArrDate.shape)

U,s,V = np.linalg.svd(ArrDate)
print(U)
print(s)
print(V)
print(np.shape(U))
print(np.shape(V))
np.savetxt('s.csv', s)


#选取前291维作为特征向量
LncSVD = np.zeros((495,291))
for i in range(495):
    for j in range(291):
        LncSVD[i,j] = U[i, j]

np.savetxt('miRNASVD.csv', LncSVD)

DisSVD = np.zeros((383,291))
for i in range(383):
    for j in range(291):
        DisSVD[i,j] = V[j,i]
np.savetxt('DisSVD.csv', DisSVD)




