import matplotlib
import pandas as pd

matplotlib.use('agg')
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

mir = np.loadtxt('mirna-result.txt')
dis = np.loadtxt('disease-result.txt')
sns.set(font_scale=1.5)
f, hm = plt.subplots(figsize=(30,30))
xyticklabels = pd.read_csv('miRNA number.csv')
print(xyticklabels['miRNAname'])
#yticklabels = pd.read_csv('disease number.csv')
#plt.imshow(mir, interpolation='nearest', cmap="GnBu", origin='upper')
#plt.imshow(dis, interpolation='nearest', cmap="OrRd", origin='upper')
#plt.colorbar(shrink=.92)
#plt.title('miRNA similarity',fontdict={'weight':'normal','size': 70})
hm = sns.heatmap(mir,
                 cbar=True,
                 annot=True,
                 square=True,
                 fmt='.2f',
                 vmin=0,vmax=1,cmap="GnBu",xticklabels = xyticklabels['miRNAname'], yticklabels = xyticklabels['miRNAname'],
                linewidths = 0.05,
                 annot_kws={'size': 20})
#plt.ylabel('True label')
#plt.xlabel('Predicted label')
plt.savefig('miRNASim.jpg', format='jpg')
#plt.savefig('diseaseSim.jpg',format='jpg')